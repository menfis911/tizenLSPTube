# Decoder corresponding source

mpg123-decoder 1.0.3 and @wasm-audio-decoders/common 9.0.7: eshaz/wasm-audio-decoders commit 8f2428c1cd96b54dab74836c8471ff75fe35cbee (MIT declaration in README/package metadata).
libmpg123: madebr/mpg123 commit 08247b317163175e62035893af3ff9e71a5dfefd (LGPL 2.1; original notices in modules/mpg123/COPYING and source headers).
simple-yenc 1.0.4: complete npm source and MIT license included; CRC32 references GCC libiberty; GCC source/notice included.
puff 2.3: Mark Adler, source and zlib-style notice in src/common/src/puff.

These are unmodified upstream sources; LSPTube integration is in the public LSPTube repository. Only the MPEG decoder and common runtime are linked; unrelated decoders are omitted.

Rebuild/relink: use Emscripten 4.0.7, Node 18+ and GNU make as documented by upstream README. Install root dependencies and the src/common and src/mpg123-decoder package dependencies. Create tmp/ and demo/; run make mpg123-configure and make mpg123-decoder (instead of the all-decoder targets). The Makefile and complete libmpg123 sources are included. The npm package's EmscriptenWasm.js is the prebuilt artifact, not hand-written source.

To use a rebuilt decoder in LSPTube, replace src/vot/node_modules/mpg123-decoder/src/EmscriptenWasm.js (and edited JS wrapper files if needed), then run npm run build --prefix src/vot and python3 scripts/build.py. LSPTube does not authenticate/checksum the decoder at runtime. Application packages are signed locally by their installer.
